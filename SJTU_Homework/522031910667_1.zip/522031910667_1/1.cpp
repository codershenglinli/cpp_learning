#include <iostream>
using namespace std;
int main(){
    cout << "Class" <<endl;
    cout << "Number" <<endl;
    cout << "Phone" <<endl;
    cout << "Address" <<endl;
    return 0;
}
#include <iostream>
using namespace std;
int main(){
    cout << "1" <<endl;
    cout << "2  4" <<endl;
    cout << "3  6  9" <<endl;
    cout << "4  8  12" <<endl;
    cout << "5  10 15 20" <<endl;
    return 0;
}
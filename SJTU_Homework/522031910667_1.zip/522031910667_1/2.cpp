#include <iostream>
using namespace std;
int main(){
    cout << "2*3+4=10";
    return 0;
}
#include <iostream>
using namespace std;
int main(){
    cout << "  R  " <<endl;
    cout << " RSR " <<endl;
    cout << "RSSSR" <<endl;
    cout << " RSR " <<endl;
    cout << "  R  " <<endl;
    return 0;
}